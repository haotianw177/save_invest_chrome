export function costInHours(price, hourlyWage) {
  return price / hourlyWage;
}
